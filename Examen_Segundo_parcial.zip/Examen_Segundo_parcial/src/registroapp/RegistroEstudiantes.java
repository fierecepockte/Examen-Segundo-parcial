package registroapp;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;

public class RegistroEstudiantes extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textFieldNombre;
    private JTextField textFieldCarnet;
    private JTextField textFieldFechaNacimiento;
    private JComboBox<String> comboBoxCarrera;
    private JRadioButton rdbtnNewRadioButtonFemenino;
    private JRadioButton rdbtnNewRadioButtonMaculino;
    private JCheckBox chckbxNewCheckBoxMusica;
    private JCheckBox chckbxNewCheckBoxDeportes;
    private JCheckBox chckbxNewCheckBoxLectura;
    private JTable tableSalida;
    private DefaultTableModel modeloTabla;
    private ArrayList<Persona> listaEstudiantes = new ArrayList<>();
    private JLabel lblNewLabel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    RegistroEstudiantes frame = new RegistroEstudiantes();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public RegistroEstudiantes() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 619, 429);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(135, 206, 250));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lbtitulo = new JLabel("Registro de estudiantes");
        lbtitulo.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        lbtitulo.setBounds(240, 10, 141, 29);
        contentPane.add(lbtitulo);

        JLabel lbNombrecompleto = new JLabel("Nombre completo:");
        lbNombrecompleto.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        lbNombrecompleto.setHorizontalAlignment(SwingConstants.LEFT);
        lbNombrecompleto.setBounds(10, 62, 120, 13);
        contentPane.add(lbNombrecompleto);

        JLabel lblNewLabel_1 = new JLabel("Cédula de identidad:");
        lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
        lblNewLabel_1.setBounds(10, 102, 120, 13);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("Fecha de nacimiento:");
        lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        lblNewLabel_2.setBounds(10, 146, 120, 13);
        contentPane.add(lblNewLabel_2);

        textFieldNombre = new JTextField();
        textFieldNombre.setBackground(new Color(224, 255, 255));
        textFieldNombre.setBounds(164, 59, 265, 19);
        contentPane.add(textFieldNombre);
        textFieldNombre.setColumns(10);

        textFieldCarnet = new JTextField();
        textFieldCarnet.setBackground(new Color(224, 255, 255));
        textFieldCarnet.setBounds(165, 99, 264, 19);
        contentPane.add(textFieldCarnet);
        textFieldCarnet.setColumns(10);

        textFieldFechaNacimiento = new JTextField();
        textFieldFechaNacimiento.setBackground(new Color(224, 255, 255));
        textFieldFechaNacimiento.setBounds(164, 143, 265, 19);
        contentPane.add(textFieldFechaNacimiento);
        textFieldFechaNacimiento.setColumns(10);

        JLabel lblNewLabel_3 = new JLabel("Carrera");
        lblNewLabel_3.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        lblNewLabel_3.setBounds(10, 187, 45, 13);
        contentPane.add(lblNewLabel_3);

        comboBoxCarrera = new JComboBox<>();
        comboBoxCarrera.setBackground(new Color(224, 255, 255));
        comboBoxCarrera.setBounds(164, 183, 265, 21);
        comboBoxCarrera.addItem("Seleccione Carrera......");
        comboBoxCarrera.addItem("Ingeniería de Sistemas");
        comboBoxCarrera.addItem("Ingeniería Industrial");
        comboBoxCarrera.addItem("Ingeniería Civil");
        comboBoxCarrera.addItem("Telecomunicaciones");
        contentPane.add(comboBoxCarrera);
        


        rdbtnNewRadioButtonFemenino = new JRadioButton("Femenino");
        rdbtnNewRadioButtonFemenino.setBackground(new Color(135, 206, 250));
        rdbtnNewRadioButtonFemenino.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        rdbtnNewRadioButtonFemenino.setBounds(116, 226, 103, 21);
        contentPane.add(rdbtnNewRadioButtonFemenino);

        rdbtnNewRadioButtonMaculino = new JRadioButton("Masculino");
        rdbtnNewRadioButtonMaculino.setBackground(new Color(135, 206, 250));
        rdbtnNewRadioButtonMaculino.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        rdbtnNewRadioButtonMaculino.setBounds(278, 226, 103, 21);
        contentPane.add(rdbtnNewRadioButtonMaculino);

        JLabel lblNewLabel_5 = new JLabel("Hobbies:");
        lblNewLabel_5.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        lblNewLabel_5.setBounds(10, 266, 60, 13);
        contentPane.add(lblNewLabel_5);

        chckbxNewCheckBoxMusica = new JCheckBox("Música");
        chckbxNewCheckBoxMusica.setBackground(new Color(135, 206, 250));
        chckbxNewCheckBoxMusica.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        chckbxNewCheckBoxMusica.setBounds(116, 262, 93, 21);
        contentPane.add(chckbxNewCheckBoxMusica);

        chckbxNewCheckBoxDeportes = new JCheckBox("Deportes");
        chckbxNewCheckBoxDeportes.setBackground(new Color(135, 206, 250));
        chckbxNewCheckBoxDeportes.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        chckbxNewCheckBoxDeportes.setBounds(240, 262, 93, 21);
        contentPane.add(chckbxNewCheckBoxDeportes);

        chckbxNewCheckBoxLectura = new JCheckBox("Lectura");
        chckbxNewCheckBoxLectura.setBackground(new Color(135, 206, 250));
        chckbxNewCheckBoxLectura.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        chckbxNewCheckBoxLectura.setBounds(376, 262, 93, 21);
        contentPane.add(chckbxNewCheckBoxLectura);

        // Crear y configurar la tabla
        
        tableSalida = new JTable();
        modeloTabla = new DefaultTableModel(
            new String[] { "Nombre", "Cédula", "Fecha", "Carrera", "Sexo", "Hobbies" },
            0
        );
        tableSalida.setModel(modeloTabla);

        JScrollPane scroll = new JScrollPane(tableSalida);
        scroll.setBounds(10, 303, 585, 90);
        contentPane.add(scroll);
        
        // Carga los datos de las personas guardadas
        
        List<Persona> guardadas = Persona.loadFromFile();
        for (Persona p : guardadas) {
            modeloTabla.addRow(new Object[]{
                p.getNombre(), p.getCedula(), p.getFechaNacimiento(),
                p.getCarrera(), p.getSexo(), p.getHobbies()
            });
        }
        
        // Botón Aceptar
        
        JButton btnNewButtonAceptar = new JButton("Aceptar");
        btnNewButtonAceptar.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        btnNewButtonAceptar.setBackground(new Color(135, 206, 250));
        btnNewButtonAceptar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 1. Leer datos
                String nombre = textFieldNombre.getText().trim();
                String cedula = textFieldCarnet.getText().trim();
                String fecha = textFieldFechaNacimiento.getText().trim();
                String carrera = (String) comboBoxCarrera.getSelectedItem();

                // 2. Validar que no seleccione ambos sexos
                
                if (rdbtnNewRadioButtonMaculino.isSelected() && rdbtnNewRadioButtonFemenino.isSelected()) {
                    JOptionPane.showMessageDialog(
                        null,
                        "Error: Solo puede seleccionar un género, no ambos a la vez.",
                        "Selección Inválida",
                        JOptionPane.ERROR_MESSAGE
                    );
                    return;
                }

                // 3. Determinar sexo
                
                String sexo = "";
                if (rdbtnNewRadioButtonMaculino.isSelected()) {
                    sexo = "Masculino";
                } else if (rdbtnNewRadioButtonFemenino.isSelected()) {
                    sexo = "Femenino";
                }

                // 4. Leer hobbies
                
                List<String> hobbiesList = new ArrayList<>();
                if (chckbxNewCheckBoxMusica.isSelected())   hobbiesList.add("Música");
                if (chckbxNewCheckBoxDeportes.isSelected()) hobbiesList.add("Deportes");
                if (chckbxNewCheckBoxLectura.isSelected())  hobbiesList.add("Lectura");
                String hobbies = String.join(", ", hobbiesList);

                // 5. Validaciones de campos
                
                if (nombre.isEmpty() || cedula.isEmpty() || fecha.isEmpty() || "Seleccione Carrera......".equals(carrera)) {
                    JOptionPane.showMessageDialog(null, "Debe completar todos los campos obligatorios.");
                    return;
                }
                if (!cedula.matches("\\d+")) {
                    JOptionPane.showMessageDialog(null, "La cédula debe ser un número.");
                    return;
                }
                if (sexo.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Seleccione un sexo.");
                    return;
                }
                if (hobbiesList.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Seleccione al menos un hobby.");
                    return;
                }

                // 6. Crear y guardar el objeto Persona
                
                Persona p = new Persona(nombre, cedula, fecha, carrera, sexo, hobbies);
                listaEstudiantes.add(p);
                p.saveToFile();

                // 7. Agregar fila a la tabla
                
                modeloTabla.addRow(new Object[] { nombre, cedula, fecha, carrera, sexo, hobbies });
            }
        });
        btnNewButtonAceptar.setBounds(459, 58, 85, 21);
        contentPane.add(btnNewButtonAceptar);

        // Botón Limpiar
        
        JButton btnNewButtonLimpiar = new JButton("Limpiar");
        btnNewButtonLimpiar.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        btnNewButtonLimpiar.setBackground(new Color(135, 206, 250));
        btnNewButtonLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textFieldNombre.setText("");
                textFieldCarnet.setText("");
                textFieldFechaNacimiento.setText("");
                comboBoxCarrera.setSelectedIndex(0);
                rdbtnNewRadioButtonMaculino.setSelected(false);
                rdbtnNewRadioButtonFemenino.setSelected(false);
                chckbxNewCheckBoxMusica.setSelected(false);
                chckbxNewCheckBoxDeportes.setSelected(false);
                chckbxNewCheckBoxLectura.setSelected(false);
            }
        });
        btnNewButtonLimpiar.setBounds(459, 98, 85, 21);
        contentPane.add(btnNewButtonLimpiar);

        // Botón Salir
        
        JButton btnNewButtonSalir = new JButton("Salir");
        btnNewButtonSalir.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        btnNewButtonSalir.setBackground(new Color(135, 206, 250));
        btnNewButtonSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        btnNewButtonSalir.setBounds(459, 142, 85, 21);
        contentPane.add(btnNewButtonSalir);
        
        lblNewLabel = new JLabel("Sexo");
        lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 11));
        lblNewLabel.setBounds(10, 230, 45, 13);
        contentPane.add(lblNewLabel);
    }
}
