package registroapp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


// Esta clase representa a una Persona que será registrada en la aplicación.
  

public class Persona {
    
    // Atributos privados de cada persona
	
    private String nombre;
    private String cedula;
    private String fechaNacimiento;
    private String carrera;
    private String sexo;
    private String hobbies;

    // Crea un archivo donde se guardaran los datos de las personas
    
    private static final String FILE_PATH = "personas.txt";

    // Constructor: crea una nueva Persona con toda su información.
     
    public Persona(String nombre, String cedula, String fechaNacimiento,
                   String carrera, String sexo, String hobbies) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.fechaNacimiento = fechaNacimiento;
        this.carrera = carrera;
        this.sexo = sexo;
        this.hobbies = hobbies;
    }

    // Métodos "getter": permiten obtener la información de la persona
    
    public String getNombre() { return nombre; }
    public String getCedula() { return cedula; }
    public String getFechaNacimiento() { return fechaNacimiento; }
    public String getCarrera() { return carrera; }
    public String getSexo() { return sexo; }
    public String getHobbies() { return hobbies; }

    // Método para mostrar la información de la persona en forma de texto legible.
     
    @Override
    public String toString() {
        return String.format(
            "Persona[nombre=%s, cedula=%s, fechaNacimiento=%s, carrera=%s, sexo=%s, hobbies=%s]",
            nombre, cedula, fechaNacimiento, carrera, sexo, hobbies
        );
    }

    public void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH, true))) {
            String line = String.join(";", nombre, cedula, fechaNacimiento, carrera, sexo, hobbies);
            writer.write(line);      // Escribe los datos
            writer.newLine();         // Salta a una nueva línea para la próxima persona
        } catch (IOException e) {
            e.printStackTrace();      // Si ocurre un error al guardar, muestra el error en la consola
        }
    }

    // Carga todas las personas guardadas desde el archivo personas.txt.

    public static List<Persona> loadFromFile() {
        List<Persona> personas = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {    // Lee cada línea del archivo
                String[] parts = line.split(";");            // Divide la línea por el punto y coma
                if (parts.length == 6) {                     // Asegura que hay 6 datos
                    Persona p = new Persona(
                        parts[0], parts[1], parts[2],
                        parts[3], parts[4], parts[5]
                    );
                    personas.add(p); // Agrega la persona a la lista
                }
            }
        } catch (IOException e) {
            // Si hay un error devuelve listas vacia
        }
        return personas;
    }
}


    

